

// Function to validate the personal information form
function validatePersonalInfoForm() {
    const firstName = document.getElementById('fname').value;
    const lastName = document.getElementById('lname').value;
    const gender = document.getElementById('gender').value;
    const email = document.getElementById('email').value;
    const phone = document.getElementById('phone').value;
    const address = document.getElementById('address').value;
  
    if (firstName === '' || lastName === '' || gender === 'Not selected' || email === '' || phone === '' || address === '') {
      alert('Please fill in all the fields.');
      return false;
    }
  
    return true;
  }
  

  /*document.addEventListener('DOMContentLoaded', function () 
  {
    const personalInfoForm = document.getElementById('personal-info-form');
    personalInfoForm.addEventListener('submit', function (event) {
      if (!validatePersonalInfoForm()) {
        event.preventDefault(); 
      }
    });
  });*/
  