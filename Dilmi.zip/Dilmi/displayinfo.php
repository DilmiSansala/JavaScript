<?php
include_once 'connection.php';
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            /* display: flex; */
            flex-direction: column;
            align-items: center;
            justify-content: center;
            margin: 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid #ccc;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        a {
            text-decoration: none;
        }

        .content {
            text-align: center;
        }
        .styled-button {
            background-color: #007BFF; /* Background color */
            color: #fff; /* Text color */
            border: none; /* Remove button border */
            padding: 8px 16px; /* Padding inside the button */
            cursor: pointer; /* Add pointer cursor on hover */
            border-radius: 4px; /* Add rounded corners */
            transition: background-color 0.3s ease; /* Smooth background color transition */
        }

        .styled-button:hover {
            background-color: #0056b3; /* Change background color on hover */
        }
        .delete-button {
            background-color: #FF0000; /* Background color for deletion */
            color: #fff; /* Text color */
            border: none; /* Remove button border */
            padding: 8px 16px; /* Padding inside the button */
            cursor: pointer; /* Add pointer cursor on hover */
            border-radius: 4px; /* Add rounded corners */
            transition: background-color 0.3s ease; /* Smooth background color transition */
        }

        .delete-button:hover {
            background-color: #CC0000; /* Change background color on hover */
        }

    </style>
    <title>Home | www.ICSCbank.com</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
</head>

<body>
    <header>
        <div class="logo">
            <img src="logo.png" alt="Logo" height="75" width="75">
        </div>
        <div class="site-name">
            <h1>ICSC Bank</h1>
        </div>
        <div class="right-section">
            <div class="search-bar">
                <i class="fa fa-search" aria-hidden="true"></i>
                <input type="text" placeholder="Search">
            </div>
            <div class="select-bar">
                <select>
                    <option value="option1">Account Type</option>
                    <option value="option2">Savings Account</option>
                    <option value="option3">Current Account</option>
                    <option value="option4">Joint Account</option>
                    <option value="option5">Fixed Deposit</option>
                </select>
            </div>
            <div class="login">
                <button>Login</button>
            </div>
            <div class="signup">
                <button>Sign Up</button>
            </div>
        </div>
    </header>

    <div class="content">
        <?php
        $query = "SELECT * FROM personal_info";
        $data = mysqli_query($conn, $query);
        $total = mysqli_num_rows($data);

        if ($total != 0) {
        ?>

        <h2 align="center">Payment Information</h2>
        <br/><br/>
        <table>
            <tr>
                <th>ID</th>
                <th>First Name</th>
                <th>Last name</th>
                <th>Gender</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Address</th>
            </tr>
            <?php
            while ($result = mysqli_fetch_assoc($data)) {
                echo "<tr> 
                    <td>" . $result['id'] . "</td>
                    <td>" . $result['fname'] . "</td>
                    <td>" . $result['lname'] . "</td>
                    <td>" . $result['gender'] . "</td>
                    <td>" . $result['email'] . "</td>
                    <td>" . $result['phone'] . "</td>
                    <td>" . $result['address'] . "</td>
                    <td><a href='update.php?id=$result[id]&fname=$result[fname]&lname=$result[lname]&gender=$result[gender]&email=$result[email]&phone=$result[phone]&address=$result[address]'>
                    <button class='styled-button'>Update</button></a>

                    <a class='delete-button' href='delete.php?id=$result[id]'>
                    <button class='styled-button delete-button'>Delete</button>

                </a>
                    </td>
                </tr>";
            }
        } else {
            echo "No payment information available.";
        }
        ?>
        </table>
    </div>
</body>

</html>
